import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class StudentApp_953 extends JFrame {
    // --- DB connection settings: change to match your MySQL setup ---
    private static final String DB_URL_953 = "jdbc:mysql://localhost:3306/college_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone";
    private static final String DB_USER_953 = "root";
    private static final String DB_PASS_953 = "1234";
    
    // --- Swing components (names include _952) ---
    private JTextField idField_953, _953, deptField_953, marksField_953;
    private JTextField searchNameField_953;
    private JButton saveBtn_953, clearBtn_953, searchBtn_953;

    // --- JDBC connection ---
    private Connection conn_953;

    public StudentApp_953() {
        super("Student Database - MySQL + Swing (_953)");
        initDB_953();
        initUI_953();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(540, 320);
        setLocationRelativeTo(null);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                closeDB_953();
            }
        });
    }

    private void initDB_953() {
        try {
            // Ensure MySQL Connector/J jar is on classpath
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn_953 = DriverManager.getConnection(DB_URL_953, DB_USER_953, DB_PASS_953);

            // Create table if not exists
            String createSQL_953 = "CREATE TABLE IF NOT EXISTS students (" +
                    "id INT PRIMARY KEY, " +
                    "name VARCHAR(100) NOT NULL, " +
                    "department VARCHAR(100), " +
                    "marks INT" +
                    ");";
            try (Statement stmt_953 = conn_953.createStatement()) {
                stmt_953.execute(createSQL_953);
            }
        } catch (ClassNotFoundException e) {
            showErrorAndExit_953("MySQL JDBC driver not found. Add mysql-connector-java.jar to classpath.");
        } catch (SQLException e) {
            showErrorAndExit_953("DB error: " + e.getMessage());
        }
    }

    private void initUI_953() {
        JPanel mainPanel_953 = new JPanel(new BorderLayout(10, 10));

        JPanel formPanel_953 = new JPanel(new GridLayout(4, 2, 6, 6));
        formPanel_953.setBorder(BorderFactory.createTitledBorder("Add Student (_953)"));

        idField_953 = new JTextField();
        _953 = new JTextField();
        deptField_953 = new JTextField();
        marksField_953 = new JTextField();

        formPanel_953.add(new JLabel("ID (integer):"));
        formPanel_953.add(idField_953);
        formPanel_953.add(new JLabel("Name:"));
        formPanel_953.add(_953);
        formPanel_953.add(new JLabel("Department:"));
        formPanel_953.add(deptField_953);
        formPanel_953.add(new JLabel("Marks (integer):"));
        formPanel_953.add(marksField_953);

        JPanel btnPanel_953 = new JPanel();
        saveBtn_953 = new JButton("Save");
        clearBtn_953 = new JButton("Clear");
        btnPanel_953.add(saveBtn_953);
        btnPanel_953.add(clearBtn_953);

        saveBtn_953.addActionListener(e -> saveStudent_953());
        clearBtn_953.addActionListener(e -> clearInputs_953());

        JPanel topPanel_953 = new JPanel(new BorderLayout());
        topPanel_953.add(formPanel_953, BorderLayout.CENTER);
        topPanel_953.add(btnPanel_953, BorderLayout.SOUTH);

        // Search Panel
        JPanel searchPanel_953 = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        searchPanel_953.setBorder(BorderFactory.createTitledBorder("Search by Name (_953)"));
        searchPanel_953.add(new JLabel("Name:"));
        searchNameField_953 = new JTextField(18);
        searchPanel_953.add(searchNameField_953);
        searchBtn_953 = new JButton("Search");
        searchPanel_953.add(searchBtn_953);
        searchBtn_953.addActionListener(e -> searchStudentByName_953());

        mainPanel_953.add(topPanel_953, BorderLayout.CENTER);
        mainPanel_953.add(searchPanel_953, BorderLayout.SOUTH);

        setContentPane(mainPanel_953);
    }

    private void saveStudent_953() {
        String idText_953 = idField_953.getText().trim();
        String name_953 = _953.getText().trim();
        String dept_953 = deptField_953.getText().trim();
        String marksText_953 = marksField_953.getText().trim();

        if (idText_953.isEmpty() || name_953.isEmpty() || marksText_953.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter ID, Name and Marks.", "Input required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id_953, marks_953;
        try {
            id_953 = Integer.parseInt(idText_952);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID must be an integer.", "Invalid ID", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            marks_953 = Integer.parseInt(marksText_953);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Marks must be an integer.", "Invalid Marks", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String insertSQL_953 = "INSERT INTO students (id, name, department, marks) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstInsert_953 = conn_953.prepareStatement(insertSQL_953)) {
            pstInsert_953.setInt(1, id_953);
            pstInsert_953.setString(2, name_953);
            pstInsert_953.setString(3, dept_953.isEmpty() ? null : dept_953);
            pstInsert_953.setInt(4, marks_953);
            pstInsert_953.executeUpdate();
            JOptionPane.showMessageDialog(this, "Student saved successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearInputs_953();
        } catch (SQLException ex) {
            String msg_953 = ex.getMessage() == null ? ex.toString() : ex.getMessage();
            if (msg_953.toLowerCase().contains("duplicate") || msg_953.toLowerCase().contains("constraint")) {
                JOptionPane.showMessageDialog(this, "A student with this ID already exists. Use a different ID.", "Duplicate ID", JOptionPane.ERROR_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "Error saving student: " + msg_953, "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void searchStudentByName_953() {
        String name_953 = searchNameField_953.getText().trim();
        if (name_953.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a name to search.", "Input required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String query_953 = "SELECT id, name, department, marks FROM students WHERE LOWER(name) = LOWER(?)";
        try (PreparedStatement pstSearch_953 = conn_953.prepareStatement(query_953)) {
            pstSearch_953.setString(1, name_953);
            try (ResultSet rs_953 = pstSearch_953.executeQuery()) {
                StringBuilder sb_953 = new StringBuilder();
                boolean found_953 = false;
                while (rs_953.next()) {
                    found_953 = true;
                    sb_953.append("ID: ").append(rs_953.getInt("id")).append("\n");
                    sb_953.append("Name: ").append(rs_953.getString("name")).append("\n");
                    sb_953.append("Department: ").append(rs_953.getString("department")).append("\n");
                    sb_953.append("Marks: ").append(rs_953.getInt("marks")).append("\n");
                    sb_953.append("---------------------------\n");
                }
                if (found_953) {
                    JTextArea area_953 = new JTextArea(sb_953.toString());
                    area_953.setEditable(false);
                    area_953.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
                    JScrollPane sp_953 = new JScrollPane(area_953);
                    sp_953.setPreferredSize(new Dimension(420, 160));
                    JOptionPane.showMessageDialog(this, sp_953, "Search result(s) for '" + name_953 + "'", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "No student found with name: " + name_953, "Not found", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error searching: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearInputs_953() {
        idField_953.setText("");
        _953.setText("");
        deptField_953.setText("");
        marksField_953.setText("");
    }

    private void closeDB_953() {
        if (conn_953 != null) {
            try {
                conn_953.close();
            } catch (SQLException ignored) {}
        }
    }

    private void showErrorAndExit_953(String msg_953) {
        JOptionPane.showMessageDialog(this, msg_953, "Fatal Error", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            StudentApp_953 app_953 = new StudentApp_953();
            app_953.setVisible(true);
        });
    }
}/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LEERA DEEP
 */
public class StudentApp_953 {
    
}

